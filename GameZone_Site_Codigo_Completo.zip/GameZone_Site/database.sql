CREATE DATABASE IF NOT EXISTS gamezone;
USE gamezone;
CREATE TABLE IF NOT EXISTS jogos (
 id_jogo INT PRIMARY KEY AUTO_INCREMENT,
 nome VARCHAR(100) NOT NULL,
 plataforma VARCHAR(50) NOT NULL,
 preco DECIMAL(10,2) NOT NULL,
 estoque INT NOT NULL DEFAULT 0,
 descricao VARCHAR(500)
);
CREATE TABLE IF NOT EXISTS clientes (
 id_cliente INT PRIMARY KEY AUTO_INCREMENT,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS compras (
 id_compra INT PRIMARY KEY AUTO_INCREMENT,
 id_cliente INT NOT NULL,
 data_compra DATETIME DEFAULT CURRENT_TIMESTAMP,
 total DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);
CREATE TABLE IF NOT EXISTS itens_compra (
 id_item INT PRIMARY KEY AUTO_INCREMENT,
 id_compra INT NOT NULL,
 id_jogo INT NOT NULL,
 quantidade INT NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (id_compra) REFERENCES compras(id_compra),
 FOREIGN KEY (id_jogo) REFERENCES jogos(id_jogo)
);
INSERT INTO jogos (nome,plataforma,preco,estoque,descricao)
SELECT 'Minecraft','PC',99.90,10,'Explore e construa seu próprio mundo.'
WHERE NOT EXISTS (SELECT 1 FROM jogos WHERE nome='Minecraft' AND plataforma='PC');
INSERT INTO jogos (nome,plataforma,preco,estoque,descricao)
SELECT 'Sonic Mania','PlayStation',79.90,5,'Uma aventura veloz.'
WHERE NOT EXISTS (SELECT 1 FROM jogos WHERE nome='Sonic Mania' AND plataforma='PlayStation');
INSERT INTO jogos (nome,plataforma,preco,estoque,descricao)
SELECT 'EA SPORTS FC','Xbox',199.90,0,'Monte seu time e entre em campo.'
WHERE NOT EXISTS (SELECT 1 FROM jogos WHERE nome='EA SPORTS FC' AND plataforma='Xbox');
INSERT INTO jogos (nome,plataforma,preco,estoque,descricao)
SELECT 'Stardew Valley','PC',34.90,12,'Cuide de uma fazenda e conheça a comunidade.'
WHERE NOT EXISTS (SELECT 1 FROM jogos WHERE nome='Stardew Valley' AND plataforma='PC');
