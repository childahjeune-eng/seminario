# GameZone — site de loja de games
Projeto escolar de demonstração: HTML, CSS e JavaScript no site; Node.js + Express no servidor; MySQL no banco.

## Como executar
1. Instale Node.js LTS e MySQL Server. O MySQL Workbench facilita executar o SQL.
2. No MySQL Workbench, abra `database.sql` e execute tudo.
3. Copie `.env.example` para `.env` e ajuste `DB_PASSWORD` para a senha do MySQL do seu computador.
4. Abra o terminal nesta pasta e execute `npm install` e depois `npm start`.
5. Acesse `http://localhost:3000` no navegador. Deixe o terminal aberto.

## Funcionalidades
Catálogo conectado ao banco, pesquisa por nome/plataforma, carrinho, formulário de cliente e registro de compra demonstrativo que atualiza o estoque. Não processa pagamentos reais.

## Consultas SQL para apresentar
```sql
SELECT * FROM jogos;
SELECT nome, preco FROM jogos WHERE preco < 100;
SELECT nome, estoque FROM jogos WHERE estoque > 0;
SELECT nome, preco FROM jogos ORDER BY preco ASC;
```
Antes de publicar na internet, o sistema precisa de autenticação, proteção de dados, HTTPS e integração segura com um provedor de pagamento.
