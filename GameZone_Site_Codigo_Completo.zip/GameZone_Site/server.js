require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));
const db = mysql.createPool({
 host:process.env.DB_HOST||'localhost', user:process.env.DB_USER||'root',
 password:process.env.DB_PASSWORD||'', database:process.env.DB_NAME||'gamezone',
 waitForConnections:true, connectionLimit:10
});
app.get('/api/jogos', async (req,res)=>{
 try {
  const q='%'+String(req.query.busca||'').trim()+'%';
  const [rows]=await db.execute('SELECT * FROM jogos WHERE nome LIKE ? OR plataforma LIKE ? ORDER BY nome',[q,q]);
  res.json(rows);
 } catch(e) { console.error(e); res.status(500).json({erro:'Erro no banco. Confira o MySQL e o arquivo .env.'}); }
});
app.post('/api/compras', async (req,res)=>{
 const nome=String(req.body.nome||'').trim(), email=String(req.body.email||'').trim(), itens=req.body.itens;
 if(!nome||!email.includes('@')||!Array.isArray(itens)||!itens.length) return res.status(400).json({erro:'Informe nome, e-mail válido e itens no carrinho.'});
 const c=await db.getConnection();
 try {
  await c.beginTransaction();
  let [clients]=await c.execute('SELECT id_cliente FROM clientes WHERE email=? FOR UPDATE',[email]);
  let idCliente;
  if(clients.length){idCliente=clients[0].id_cliente; await c.execute('UPDATE clientes SET nome=? WHERE id_cliente=?',[nome,idCliente]);}
  else {const [r]=await c.execute('INSERT INTO clientes(nome,email) VALUES(?,?)',[nome,email]);idCliente=r.insertId;}
  let total=0, rows=[];
  for(const it of itens){
   const id=Number(it.id_jogo), qty=Number(it.quantidade);
   if(!Number.isInteger(id)||id<1||!Number.isInteger(qty)||qty<1) throw Error('Item inválido.');
   const [g]=await c.execute('SELECT * FROM jogos WHERE id_jogo=? FOR UPDATE',[id]);
   if(!g.length) throw Error('Jogo não encontrado.');
   if(g[0].estoque<qty) throw Error('Estoque insuficiente para '+g[0].nome+'.');
   const price=Number(g[0].preco); total+=price*qty; rows.push({id,qty,price});
  }
  const [order]=await c.execute('INSERT INTO compras(id_cliente,total) VALUES(?,?)',[idCliente,total.toFixed(2)]);
  for(const it of rows){
   await c.execute('INSERT INTO itens_compra(id_compra,id_jogo,quantidade,preco_unitario) VALUES(?,?,?,?)',[order.insertId,it.id,it.qty,it.price.toFixed(2)]);
   await c.execute('UPDATE jogos SET estoque=estoque-? WHERE id_jogo=?',[it.qty,it.id]);
  }
  await c.commit(); res.status(201).json({mensagem:'Pedido demonstrativo registrado!',id_compra:order.insertId,total:Number(total.toFixed(2))});
 } catch(e) { await c.rollback(); res.status(400).json({erro:e.message||'Erro ao registrar pedido.'}); }
 finally {c.release();}
});
app.listen(process.env.PORT||3000,()=>console.log('GameZone: http://localhost:'+(process.env.PORT||3000)));
